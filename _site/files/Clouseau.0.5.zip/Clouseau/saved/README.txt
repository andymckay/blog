These are directories for writing saved session to and reading from. There are two directories:

- local, this is blank in SVN, this is where you save the sessions you have created

- global, this is not blank, this is where we will load interesting and useful scripts for you

Saves go automatically to local. Load's can come from either.

Because we are writing into the Products directory, you will need write permissions to do that in Zope, something that normally happens anyway.