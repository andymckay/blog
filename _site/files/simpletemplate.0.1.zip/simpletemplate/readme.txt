License:

    LGPL
    
Author:

    Andy McKay
    andy@clearwind.ca

About:

    A simple implementation of the SimpleTAL library for Django. Usage is simple, install place SimpleTAL.
    
    http://www.owlfish.com/software/simpleTAL/
    
    Then place this directory in your django contrib library.
    
    On your view call get_template to load in the template you'd like:

    from django.contrib.simpletemplate import simpletemplate
    from django.template import Context
    
    [snip...]
        t = simpletemplate.get_template('recipes/recipe_detail.pt')
        # add in a standard Context
        c = Context({ 'object': r, 'code': result, "object_list":_recipe_list() })
        # and render back, simple
        return HttpResponse(t.render(c))
    
    Macros:
    
        At start up all page templates are loaded and parsed into a dictionary. Reading the 
        TEMPLATE_DIRS, the foremost directories first. If you have any problems here or templates
        don't seem to be loaded, check your syntax
        
        A templates .pt is chopped off and loaded into a templates dictionary, so to access a macro
        master in a template, main_template you'd do:
        
            metal:use-macro="templates/main_template/macros/master"
        
        Because all templates use the same namespace, another main_template could override an existing one.
    
Credit:

    Stefan Holek and ZPT for Django, a much more robust solution and I was reading bits of that when I wrote this
    
    http://www.zope.org/Members/shh/DjangoPageTemplates