# this is the first code that is run by a session
from AccessControl.SecurityManagement import newSecurityManager
from Testing.makerequest import makerequest
from cStringIO import StringIO

app = transaction_manager.beginAndGetApp()
# login the current user
acl_users = app.unrestrictedTraverse(acl_users_path)

uid = acl_users.getUserById(userid)
if uid:
    user = uid.__of__(acl_users)
    newSecurityManager(None, user)

response_output = StringIO()
app = makerequest(app, stdout=response_output)

portal = app.unrestrictedTraverse(portal_path)

# context is added in the new_namespace
if context:
    context = app.unrestrictedTraverse(context, None)
    if context is None:
        del context
else:
    # not needed
    del context

# clean out variables
del uid
del acl_users
del userid
del StringIO
del makerequest
del newSecurityManager
del portal_path