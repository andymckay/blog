# some easy shortcuts in a session so you don't have to remember them
catalog = portal.portal_catalog
types = portal.portal_types
workflow = portal.portal_workflow
skins = portal.portal_skins
fp = portal.restrictedTraverse('front-page')
