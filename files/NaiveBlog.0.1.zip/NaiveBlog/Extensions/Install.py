def install(self):
    """ Naive blog does nothing but make an install """
    # 1. copy news item portal type to blog
    pt = self.portal_types
    new_id = "Blog"
    if new_id in pt.objectIds():
        raise ValueError, "You've already got a content type called blog."
        
    copy = pt.manage_copyObjects('News Item')
    res = pt.manage_pasteObjects(copy)
    temp_id = res[0]['new_id']
    pt.manage_renameObjects([temp_id,], [new_id,])
    typ = pt._getOb(new_id)
    typ._updateProperty("title", "Blog entry")
    typ._updateProperty("allow_discussion", True)
    
    # 2. make a smart folder called blog that reads it
    folder_id = "blog"
    if folder_id in self.objectIds():
        raise ValueError, "You already have an object called blog"
    
    self.invokeFactory("Topic", id=folder_id)
    topic = self._getOb(folder_id)
    
    # add in Type and created date
    type_crit = topic.addCriterion('Type','ATPortalTypeCriterion')
    type_crit.setValue('Blog')
    sort_crit = topic.addCriterion('created','ATSortCriterion')
    
    