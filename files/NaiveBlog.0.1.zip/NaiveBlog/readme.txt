About:

    The right way to do a blog in Plone. Copies the news item content type to blog. Makes a smart folder called blog. And that's it. Simple, high chance of always working. No complicated workflows or anything else.
    
Credits:

    Andy McKay, Alexander Limi
    
License:

    GPL