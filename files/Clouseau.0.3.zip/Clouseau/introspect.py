import inspect 

# This code is completely ripped with minor to no changes
# from the PyCrust project, Patrick O'Brien and Robin Dunn
# credit to them, blame to me. Some of these functions are
# line for line copies.

def getToolTip(object, dropSelf=True):
    name = ''
    try:
        name = object.__name__
    except AttributeError:
        pass
    tip1 = ''
    argspec = ''
    if inspect.isbuiltin(object):
        # Builtin functions don't have an argspec that we can get.
        pass
    elif inspect.isfunction(object):
        # tip1 is a string like: "getCallTip(command='', locals=None)"
        argspec = apply(inspect.formatargspec, inspect.getargspec(object))
        if dropSelf:
            # The first parameter to a method is a reference to an
            # instance, usually coded as "self", and is usually passed
            # automatically by Python; therefore we want to drop it.
            temp = argspec.split(',')
            if len(temp) == 1:  # No other arguments.
                argspec = '()'
            elif temp[0][:2] == '(*': # first param is like *args, not self
                pass 
            else:  # Drop the first argument.
                argspec = '(' + ','.join(temp[1:]).lstrip()
        tip1 = name + argspec
    doc = ''
    if callable(object):
        try:
            doc = inspect.getdoc(object)
        except:
            pass
    if doc:
        # tip2 is the first separated line of the docstring, like:
        # "Return call tip text for a command."
        # tip3 is the rest of the docstring, like:
        # "The call tip information will be based on ... <snip>
        firstline = doc.split('\n')[0].lstrip()
        if tip1 == firstline or firstline[:len(name)+1] == name+'(':
            tip1 = ''
        else:
            tip1 += '\n\n'
        docpieces = doc.split('\n\n')
        tip2 = docpieces[0]
        tip3 = '\n\n'.join(docpieces[1:])
        tip = '%s%s\n\n%s' % (tip1, tip2, tip3)
    else:
        tip = tip1
    calltip = (name, argspec[1:-1], tip.strip())
    return calltip

if __name__=='__main__':
    def foo(a, b=1):
        """ A sample """
        pass

    class bar:
        def poo(a, c=None):
            """ Pass """
            pass

    def poo(a, x=1, y=2):
        # return some stuff
        return x+y * a
        
    def tooltip(thing):
        evald = eval(thing)
        return getToolTip(evald)

    b = bar()
    tests = [
    #    foo,
        "poo",
        "b.poo",
        "'a'.lower",
        "dict",
        ]

    for test in tests:
        print "*" * 40
        print "*", test
        print 
        print tooltip(test)