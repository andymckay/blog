def transform(request, data, config):
    return data