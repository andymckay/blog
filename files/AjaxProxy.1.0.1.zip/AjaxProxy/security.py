def apply(headers, config):
    pass