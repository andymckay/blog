# This library handles reading the configuration
# from the file system and returning something
# the rest of the app can use

import os
from ConfigParser import ConfigParser, NoOptionError

class config:
    def __init__(self, file):
        self.file = file
        self.data = ConfigParser()
        self.data.read(self.file)

        # data stores for fast lookup
        self._paths = {}
        self.paths()

    def services(self):
        """ Return a list of the services """
        return self.data.sections()

    def paths(self):
        """ A request will come in as a url, we
        have to provide a way to list the urls
        and map a url (a section property) back to
        a section """
        if not self._paths:
            for s in self.data.sections():
                try:
                    p = self.data.get(s, "path")
                except NoOptionError:
                    raise ValueError, "The path is not defined for the section: %s, this is required." % s
                if p and p not in self._paths:
                    self._paths[p] = s
                elif p in self._paths:
                    raise ValueError, "The path %s is defined more than once in the config, these must be unique." % p
                elif not p:
                    raise ValueError, "The path defined but is empty for the section: %s, this is required." % s
        return self._paths

    def lookup(self, key):
        """ Given an incoming url, return a dictionary
        of that sections data """
        paths = self._paths
        section = paths.get(key, None)
        if not section:
            return None

        result = {}
        for key, value in self.data.items(section):
            result[key] = value
        return result

    def sections(self):
        sections = []
        for section in self.data.sections():
            result = {}
            for key, value in self.data.items(section):
                result[key] = value
            sections.append(result)
        return sections

directory = os.path.dirname(__file__)

files = [
    "config.ini",
    os.path.join(directory, "config.ini"),
    ]

def makeDefaultConfig(default=None, destination=None):
	if not default:
		default = os.path.join(directory, "config.ini.in")
	if not os.path.exists(default):
		raise ValueError, "The default file cannot be found: %s" % default
	if not destination:
		destination = files[0]
	if os.path.exists(destination):
		# dont override existing files
		return
	try:
		destfile = open(destination, "wb")
	except IOError:
		raise IOError, "No configuration could be found and an attempt to create one at startup failed. Please read the documentation for this product"
	
	srcdata = open(default, "rb").read()
	destfile.write(srcdata)

def getConfig():
    for file in files:
        if os.path.exists(file):
            c = config(file)
            return c
    raise ValueError, "Configuration file not found, looked in: %s" % ", ".join(files)

if __name__=="__main__":
    c = getConfig()
    c.services()
    print c.lookup('/clearwind-spell')