from Products.CMFCore import utils as CMFCoreUtils
import utils

product_name = "AjaxProxy"
tools = (utils.Tool,)

import os

# make the configuration file point to the Zope
# etc directory, which is the place to store configuration
# files
from config import files, makeDefaultConfig
from cache import cache_directory, makeDefaultCache

from App import FindHomes

ih = __builtins__["INSTANCE_HOME"]
conf = os.path.join(ih, "etc", "ajax_proxy.conf")

files.insert(0, conf)
makeDefaultConfig()

# next set the cache to the var directory
dir = os.path.join(ih, "var", "ajax_proxy")

cache_directory.insert(0, dir)
makeDefaultCache()

def initialize(context):
    CMFCoreUtils.ToolInit(product_name,
                          tools = tools,
                          product_name = product_name,
                          icon='tool.gif'
                          ).initialize(context)
