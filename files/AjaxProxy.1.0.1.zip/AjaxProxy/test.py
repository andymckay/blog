import proxy
import config
import cache


def testOne():
    p = proxy.proxy()
    print p.process({}, "/clearwind-spell")

def testAll():
    c = config.getConfig()
    paths = []
    urls = []
    print "There are %s services." % len(c.services())
    for name, service in map(None, c.services(), c.sections()):
        path = service.get("path")
        url = service.get("url")
        print
        print "*" * 40
        print "Testing service:", name
        print "Incoming request:", path
        print "Goes to:", url
        if path in paths:
            raise ValueError, "The path %s is already specified, this must be unique" % path
            paths.append(path)
        if url in urls:
            print "* Warning: the URL %s is already specified, not a failure, just to let you know" % url
            urls.append(url)
        p = proxy.proxy()
        p.process({}, path)

    print "*" * 40
    print "Congratulations, all the proxies seem to work"

if __name__=="__main__":
    testAll()