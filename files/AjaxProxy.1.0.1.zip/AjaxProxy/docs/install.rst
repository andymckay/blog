Installing and Configuring AjaxProxy
==============================================================================

- Unzip the zip file.

- Copy the zip file into your Products directory. Ensure that you have a folder structure matching: Products/AjaxProxy/__init__.py

- Restart Zope

- Go to the Plone control panel (via site setup)

- Click on Add/Remove Products

- Check the AjaxProxy box

- Click Install

Configure the services
------------------------------------------------------------------------------------------------

Rather than rely on ZODB based configuration management, this tool relies upon a file system based configuration file. The configuration file is loaded into the same directory as your zope.conf files, namely INSTANCE_HOME/etc.

The file is called ajax_proxy.conf and is written in the Python Config Parser format.

To ensure that your ajax-proxy tool is not an open proxy (ie: allowing anyone to proxy anything to anything), the ajax-proxy tool will only proxy url's that are explicitly set in the configuration file, if it's not there, it will not proxy it.

Here's a sample configuration::

    1   [clearwind-spelling]
    2   path = /clearwind-spell
    3   url = http://www.clearwind.ca/services/spell.py
    4   cache =
    5   cache-headers = url
    6   cache-length = 60
    7   transform =
    8   security = View

Let's run through these lines and explain it a bit more.

1.  (Required) This is the name of the service, it has to be unique. But it's not used anywhere other than internal, to keep your life sane, keep this something short and descriptive.

2.  (Required) The path that the Ajax client will be requesting. Note that the actual sent will include the tool name (more on that later), this is the path from the tool onwards, it should always start with a / and after that can be a valid url such as /clearwind-spell or /yahoo/finance/data. Please note that you must ensure that this path is UNIQUE in your configuration.

3.  (Required) The URL that the proxy will then forward the incoming request on to. In this case it will be to the site http://www.clearwind.ca/services/spell.py. Other protocols such as HTTPS should work.

4.  (Optional) This is the cache setting, if you leave it blank or omit it no caching will occur. To turn on caching, set cache to True, for example: cache=True

5.  (Optional) Define the headers that are used in caching the request, if you'd like caching based on language, then you may add that in here, by adding in Accept-Language as a header.

6.  (Optional) Set the cache length, in seconds of the data to be cached.

7.  (Optional) Not yet implemented

8.  (Optional) If not specified anyone can use this proxy. If specified, its a comma seperated list of all the Zope permissions required to call this proxy. For example to only people you can modify content set this to: security = Modify portal content. The permission checked is the permission on the ajax_proxy_tool, to alter those you can simply go to the ajax_proxy_tool in the ZMI and alter settings on the security tab.

The configuration file is read on each request, so no restart is necessary (although later optimisations might find that to be unwieldy).


Testing
----------------------------------------------------------------------------------------
Next in the AjaxProxy directory, run the test.py script. This will check your configuration file for some common issues and run tests on the URL's to check they actually work.

At this point I would suggest configuring the services for the clearwind spelling and move on to the Using guide.


Copyright ClearWind Consulting, 2006
License: ClearWind restricted license see http://www.clearwind.ca/licenses/restricted
