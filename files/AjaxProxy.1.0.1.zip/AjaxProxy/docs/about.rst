About
==========================================================================

One of the most popular new patterns recently is Ajax. Whilst a powerful pattern it has a problem, you cannot make a request from one site to another site, it will only allow you to make requests the same site. This is by design in xmlHTTPRequest.

Unfortunately one of the most useful things to do is able to do this, if you can have a data source anywhere and pull it in through Ajax you can provide a cross between Ajax and Web Services. It's a simple form of the more full blown Web Services that is easy to setup and install without getting into the complicated land of Web Services.

This module allows you to make Ajax requests on your users browser to any other server on the web, allowing to mix and match services from Yahoo, Google and other providers on to your site.

What does this module actually do?
----------------------------------------------------------------------------------------------------

This provides a simple proxy inside Plone, so that requests to the Plone server are forwarded on to another server. But wait there's more:

-   Caching: requests on the way back from the server can optionally be cached inside Plone, this greatly cuts down on your network traffic and gives you a great speed increase.

-   Security: when a request comes through you can optionally apply Zope and Plone security to the request, forcing people to be properly authenticated to make requests.

-   Transformations: when the request comes back from the server, you can optionally transform the XML that is returned using XSLT pipelines (not currently implemented, in progress).

But....
----------------------------------------------------------------------------------------------------

Can't this be done in Apache or Squid? Mostly it can be by setting up a few configuration options in the Apache config. But it will only get you so far, there are few things it can't do namely security and transformations. Further with testing tools, documentation, examples and an out of the box working system for any Plone this offers more convenience.

Where next?
----------------------------------------------------------------------------------------------------

Read the installation documentation and then go read the using documentation. This should get you up and running.

Many Ajax appplications await, go forth and pull them all into the Plone world ... and don't forget to send your new applications to the community for the greater good.

Future
----------------------------------------------------------------------------------------------------

This is a prototype to prove that the concept is useful. Further features will come if this proves useful.

Copyright ClearWind Consulting, 2006
License: ClearWind restricted license see http://www.clearwind.ca/licenses/restricted
