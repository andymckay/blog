Using Ajax Proxy
======================================================================

This assumes that you've read the installation documentation and have set up at least one URL to be proxied.

The use of Ajax Proxy is very simple, all you have to is call the right URL in your Ajax library to trigger the proxying component of the Ajax Proxy. The url of that will be the URL to your Plone site (for example http://some.plone.site) with a bit extra appended to the URL. You need to add /ajax_proxy_tool (the name of the tool), /proxy (the namespace for proxying), then the *path* from the configuration file.

So if your configuration file has::

    path = /clearwind-spell

Your URL would be::

    http://some.plone.site/ajax_proxy_tool/proxy/clearwind-spell

That's it, the tool will take care of the rest, doing security, proxying caching as appropriate through the tool and return you a response.

What rules are there about the server?
---------------------------------------------

- At this point anything that requires a GET or a POST. If you send data in the request, it is encoded and passed on in a POST to the server.

- The proxy tool only accepts text/xml from the server, so make sure that your server produces text/xml, which is what Ajax really wants to see anyway.

Errors
---------------------------------------------

If an error occurs on the server, then it is raised back down the pipe using the URL status codes. This does cause a bit of confusion, because it is theoretically possible for a 500 error (for example) to occur in two places, the proxy server (Plone) or the end server. If you are getting errors and are ensure where, be sure to test the server before looking at the proxy.

In your Ajax application, you just need to handle non 200 status codes as normal.