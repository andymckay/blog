Copyright ClearWind Consulting, 2006
License: LGPL

Requirements:

- AjaxProxy (from ClearWind)

- Access to http://www.clearwind.ca/services/spell.py from the Plone server (not the client)

Install:

- ensure that ajax_proxy.conf (see the AjaxProxy docs) has the following:

[clearwind-spelling]
path = /clearwind-spell
url = http://www.clearwind.ca/services/spell.py

- go to Add/Remove Products and install ClearSpell

- restart Zope

About:
    
    A prototype product to prove that it works. It allows you to install a spell checker into Plone that requires no software to be installed. Adds in a little spell check icon to each textarea and input box (even works with Kupu), mouse over it to get a spell check.
    
    May work for you, more to prove that AjaxProxy works than anything
    
Author:

    Andy McKay
    andy@clearwind.ca
