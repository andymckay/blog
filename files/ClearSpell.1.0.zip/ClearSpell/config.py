product_name = "ClearSpell"
layer_name = "clearspell"
layer_location = "ClearSpell/skins"