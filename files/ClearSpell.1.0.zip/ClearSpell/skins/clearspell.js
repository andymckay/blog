/* 
    Copyright: ClearWind Consulting, 2006
    See license.txt
    
    $Id: spellchecker.js 8 2006-07-12 23:39:01Z andy $
*/

// override this with your spell.py location
var spellcheck_url = "ajax_proxy_tool/proxy/clearwind-spell";

function spellcheck_initialize() {
    var content_area = document.getElementById("region-content");
    var elems = new Array();
    var elem = null;
    
    var temp_elems = content_area.getElementsByTagName("input");
    for (var i = 0; i < temp_elems.length; i++) {
        elem = temp_elems[i];
        if (elem.getAttribute("type") == "text") {
            elems.push(elem);
        }   
    }
    
    temp_elems = content_area.getElementsByTagName("textarea");
    for (var i = 0; i < temp_elems.length; i++) {
        elems.push(temp_elems[i]);
    }
    
    if (elems.length > 0) {
        for (var k = 0; k < elems.length; k++ ) {
            var elem = elems[k];
            var img = document.createElement("img");
            img.src = "spell-small.jpg";
            img.alt = "Mouse over to get a spell check"
            img.onmouseover = spellcheck_this;
            var par = elem.parentNode;
            par.insertBefore(img, elem.nextSibling);
        }
        // create
        var holder = document.createElement("dl");
        holder.id = "spellcheck_node";
        holder.name = "spellcheck_node";
        toggle_hide(holder)
        elems[0].parentNode.insertBefore(holder, elems[0]);
    };
}

function spellcheck_this() {
    var button = this;
    var node = this.previousSibling;
    var str = node.value;
    var req = new XMLHttpRequest()
    var root = document.documentElement;
    
    button.src = "indicator.gif";
    
    req.onreadystatechange = function() {
        if(req.readyState == 4) {
            var xml = req.responseXML.documentElement;
            var words = xml.getElementsByTagName("word");
            var results_node = document.getElementById("spellcheck_node");
            
            results_node.innerHTML = '';
            // 3 possible outcomes, error, no words, words
            
            if (req.status != 200) {
                // error!
                var error = xml.getElementsByTagName("error")[0];
                var term = document.createElement("dt");
                term.innerHTML = "Error: " + error.getAttribute("value");
                results_node.appendChild(term);
            } else {
                // yay no error
                // no words
                if (words.length < 1) {
                    var term = document.createElement("dt");
                    term.innerHTML = "No words spelled incorrectly.";
                    results_node.appendChild(term);
                } else {
                    // got some words, yay
                    for (var k=0; k < words.length; k++) {
                        var word = words[k];
                        var sugg = word.getElementsByTagName("suggestion");
                        var term = document.createElement("dt");
                        term.innerHTML = word.getAttribute("original");
                        results_node.appendChild(term);
                        var defn = document.createElement("dd");
                        var sugg_text = "";
                        for (var s=0; s < sugg.length; s++) {
                            if (sugg_text) {
                                sugg_text += ", " + sugg[s].firstChild.data;
                            } else {
                                sugg_text = sugg.length + ": " + sugg[s].firstChild.data;
                            }
                        };
                        defn.innerHTML = sugg_text;
                        results_node.appendChild(defn);
                    }
                }
            };
            
            button.src = "spell-small.jpg";;
            button.parentNode.appendChild(results_node);
            toggle_show("spellcheck_node");
        }
    };
    req.open("POST", spellcheck_url, true);
    req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    req.send("text=" + str)
    
    return false;
}

registerPloneFunction(spellcheck_initialize);