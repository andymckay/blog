/* From: http://www.quirksmode.org/dom/toc.html

modified and broken by ClearWind.
*/


function getElementsByTagNames(list, obj) {
    if (!obj) var obj = document;
    var tagNames = list.split(',');
    var resultArray = new Array();
    for (var i = 0; i < tagNames.length; i++)
    {
        var tags = obj.getElementsByTagName(tagNames[i]);
        for (var j = 0 ; j < tags.length; j++)
        {
            resultArray.push(tags[j]);
        }
    }
    var testNode = resultArray[0];
    if (testNode.sourceIndex)
    {
        resultArray.sort(function (a,b) {
                return a.sourceIndex - b.sourceIndex;
        });
    }
    else if (testNode.compareDocumentPosition)
    {
        resultArray.sort(function (a,b) {
                return 3 - (a.compareDocumentPosition(b) & 6);
        });
    }
    return resultArray;
}

function createTOC() {
    var toc = document.getElementById('clearcontents-toc');
    if (!toc) {
       return;
    }
    var elems = getElementsByTagNames('h1,h2,h3,h4');
    if (elems.length < 3) {
        return;
    }
    
    var portlet = document.getElementById("portlet-clearcontent");
    if (!portlet) {
        return;
    }
    portlet.style.display = "block";
    
    // set this to 1 to discard the first element, Portal, which isn't very useful
    for (var i=1; i < elems.length; i++) {
        var li = document.createElement('li');
        var tmp = document.createElement('a');
        var elem = elems[i];
        
        tmp.innerHTML = elem.innerHTML;
        tmp.href = '#link' + i;        
        tmp.className = 'clearcontents-link';
                        
        if (elem.nodeName != 'H1') {
            li.className = 'clearcontents-indent';
        }
        
        li.appendChild(tmp);
        toc.appendChild(li);
        
        // the return to top link, dont need for the top
        if (i < 2) {
            continue;
        }
        var tmp2 = document.createElement('a');
        var span = document.createElement('span');
        tmp2.id = 'link' + i;
        tmp2.href = '#documentContent';
        tmp2.className = "clearcontents-top";
        span.innerHTML = "Return to top";
        tmp2.appendChild(span);
        elem.parentNode.insertBefore(tmp2, elem);
    }
    
    
}

registerPloneFunction(createTOC);