from Products.ClearContents.config import *
from Products.CMFCore.DirectoryView import registerDirectory

registerDirectory('skins', product_globals)