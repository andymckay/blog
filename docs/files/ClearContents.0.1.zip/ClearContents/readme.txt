Copyright ClearWind Consulting, 2006
License: LGPL

Requirements:

    None, tested on Plone 2.5

About:
    
    Installs a cute little "Table of contents" portlet into the top left of your site. If you are viewing a peice of
    content that has more than 2 headings in it, it automatically creates a table of contents of the page. Each heading in the
    content is automatically given a "return to the top link".
    
    Helps you navigate large pages.
    
Author:

    Andy McKay
    andy@clearwind.ca
