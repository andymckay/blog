product_name = "ClearContents"
layer_name = "clearcontents"
layer_location = "ClearContents/skins"

product_globals = globals()

slots = [ "context/clearcontents-template/macros/portlet", ]