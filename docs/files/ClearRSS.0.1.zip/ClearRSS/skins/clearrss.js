function RSSRequest(url) {
    var RSSRequestObject = new XMLHttpRequest();
    
	RSSRequestObject.open("GET", url , true);
	RSSRequestObject.onreadystatechange = function ReqChange() {
    	// If data received correctly
    	if (RSSRequestObject.readyState==4) {

    		// if data is valid
    		if (RSSRequestObject.responseText.indexOf('invalid') == -1) 
    		{ 	
    			// Parsing RSS
    			var node = RSSRequestObject.responseXML.documentElement; 


    			// Get Channel information
    			var channel = node.getElementsByTagName('channel').item(0);
    			var title = channel.getElementsByTagName('title').item(0).firstChild.data;
    			var link = channel.getElementsByTagName('link').item(0).firstChild.data;

    			var page_template_title = document.getElementById("portlet-rss-title");
    			page_template_title.innerHTML = title

    			var page_template_url = document.getElementById("portlet-rss-url");
    			page_template_url.href = link

    		    var content = '';

    			// Browse items

    			var items = node.getElementsByTagName('item');
    			for (var n=0; n < items.length; n++)
    			{
    				var itemTitle = items[n].getElementsByTagName('title').item(0).firstChild.data;
    				var itemLink = items[n].getElementsByTagName('link').item(0).firstChild.data;
    				try {
    				    var d = items[n].getElementsByTagName('date').item(0).firstChild.data;
    				    // someone would have to work on this, but this works on Plone feeds
    				    d = d.substr(0, 10);
    					var itemPubDate = '<span class="portletItemDetails">' + d + '</span>';
    				} catch (e) {
    					var itemPubDate = '';
    				}

    			    var odd = n % 2 ? "even" : "odd";
    				content += '<dd class="portletItem ' + odd + '"><a href="'+itemLink+'">'+itemTitle+'</a>' + itemPubDate + '</dd>';
    			}

    			// Display the result
    			document.getElementById("rss-feed-results").innerHTML = content;

    		}
    	}

    }
	RSSRequestObject.send(null); 
}
