from Products.CMFCore.DirectoryView import createDirectoryView
from Products.CMFCore.utils import getToolByName

from Products.ClearRSS.config import layer_name, layer_location

def install(self):
    """ Install this product """
    out = []
    skinsTool = getToolByName(self, 'portal_skins')

    # add in the directory view pointing to our skin
    if layer_name not in skinsTool.objectIds():
        createDirectoryView(skinsTool, layer_location, layer_name)
        out.append('Added "%s" directory view to portal_skins' % layer_name)

    # add in the layer to all our skins    
    skins = skinsTool.getSkinSelections()
    for skin in skins:
        path = skinsTool.getSkinPath(skin)
        path = [ p.strip() for p in path.split(',') ]
        if layer_name not in path:
            path.insert(path.index('custom')+1, layer_name)

            path = ", ".join(path)
            skinsTool.addSkinSelection(skin, path)
            out.append('Added "%s" to "%s" skins' % (layer_name, skin))
        else:
            out.append('Skipping "%s" skin' % skin)
    
    # add in the clearspell js
    jsreg = getToolByName(self, 'portal_javascripts', None)
    scripts = ["clearrss.js",]
    if jsreg is not None:
        for script in scripts:
            if script not in jsreg.getResourceIds():
                jsreg.registerScript(script)
                out.append('Registered %s' % script)

    cssreg = getToolByName(self, 'portal_css', None)
    skins = ["clearrss.css",]
    if cssreg is not None:
        for skin in skins:
            stylesheet_ids = cssreg.getResourceIds()
            if skin not in stylesheet_ids:
                cssreg.registerStylesheet(skin)
                out.append("Registered %s" % skin)

    right = list(self.right_slots)
    right.insert(0, "context/portlet_clearrss/macros/portlet")
    self.right_slots = right

    return out