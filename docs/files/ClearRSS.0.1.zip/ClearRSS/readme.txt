Copyright ClearWind Consulting, 2006
License: LGPL

Requirements:

- AjaxProxy (from ClearWind)


Install:

- ensure that ajax_proxy.conf (see the AjaxProxy docs) has the following:

[clearwind-rss]
path = /clearwind-rss
url = http://www.agmweb.ca/blog/wp-rss.php
cache = True

- please change the URL to be any URL that points to a RSS feed of your choice

- go to Add/Remove Products and install ClearRSS

- restart Zope

About:
    
    A prototype product to prove that it works. It allows you to add in RSS feed parsing for any url that you'd like to use, placing it inside a 
    
    If you'd like to do more RSS feeds or show them in different ways:
    
    - alter the page template and copy as you need... pointing the url in the template to a new rss feed name
    
    - alter the config file to point to a new RSS feed, adding in a new section
    
    - fix the id's and the code in clearrss to cope with multiple id's (an exercise for someone to fix)
    
    - restart
    
    May work for you, more to prove that AjaxProxy works than anything
    
Author:

    The code was based on JS from: http://ajax.phpmagazine.net/2005/11/ajax_rss_reader_step_by_step_t.html

    It was then altered and probably broken quite a bit.

    Andy McKay
    andy@clearwind.ca
