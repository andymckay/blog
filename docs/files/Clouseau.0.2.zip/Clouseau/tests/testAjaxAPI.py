import os, sys
if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))

from Globals import package_home
import Globals
from Testing import ZopeTestCase
from Products.CMFPlone.tests import PloneTestCase

Globals.DevelopmentMode = True
ZopeTestCase.installProduct('Clouseau')

process_text = [
    [ "import urllib", ],
    [ "1 + 1", ],
    [ "x = 1", "x += 1" ],
    [ "z = 10", "for x in z:", "    print x", ],
    ]

tooltip_text = [
    [ "'asd'.lower(", ],
    ]

autocomplete_text = [
    [ "'asd'.", ],
    ]

class TestAjax(PloneTestCase.PloneTestCase):
    def setUp(self):
        # get a pointer to the tool
        PloneTestCase.PloneTestCase.setUp(self)
        self.folder.manage_addProduct['Clouseau'].manage_addTool('Clouseau', None)
        self.tool = self.folder.clouseau_tool

    def test_list_session_info(self):
        """ Expecting a simple list of sessions, each of which is
        a dictionary of:
            id: session id
            lines: number of lines in the session
            ...
        """
        sessions = self.tool.list_session_info()
        for session in sessions:
            assert isinstance(session, dict)
            assert session.get("id")
            assert session.get("lines_length")

    def test_new_session(self):
        """ Create a new session """
        # expecting new_session to return me the session
        sid = self.tool.new_session()
        # expecting the session to have an id
        # and it to be in the sessions
        sessions = self.tool.list_session_info()
        assert sid in [ s["session_id"] for s in sessions ]

    def _new_session(self):
        """ Utility function to give me new sessions """
        sid = self.tool.new_session()
        return sid

    def _test_process_text(self):
        """ Process some text """
        sid = self._new_session()
        for lines in process_text:
            for line in lines:
                self.tool.process_text(sid, line)
                assert isinstance(res, list)
                # assert something here?

    def _test_get_tooltip(self):
        """ Get tooltips """
        sid = self._new_session()
        for line in tooltip_text:
            res = self.tool.get_tooltip(sid, line)
            assert isinstance(res, list)

    def _test_get_autocomplete(self):
        """ Get autocomplete """
        sid = self._new_session()
        for line in autocomplete_text:
            res = self.tool.get_autocomplete(sid, line)
            assert isinstance(res, list)

    def _test_get_lines(self):
        """ The front end only needs line 10-12 so
        go get those """
        sid = self._new_session()
        lines = process_text[0]
        for line in lines:
            self.tool.process_text(sid, line)
            # give me back lines 1-3
        self.tool.get_lines(id, [1, 3])

    def test_block(self):
        """ This was a nightmare no-one wanted to help on """
        sid = self._new_session()
        import time
        self.tool.process_text(sid, "xx = 3")
        time.sleep(5)
        print self.tool.get_all_lines(sid)
        self.tool.process_text(sid, "if 1:")
        time.sleep(5)
        print self.tool.get_all_lines(sid)
        self.tool.process_text(sid, " xx")
        time.sleep(5)
        print self.tool.get_all_lines(sid)
        self.tool.process_text(sid, "")
        time.sleep(5)
        print self.tool.get_all_lines(sid)
        
def test_suite():
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestAjax))
    return suite

if __name__ == '__main__':
    framework()
