/* 
 * Clouseau Client Processor
 *
 * Query String parser by Peter A. Bromberg, Ph.D.
 *    Taken from: http://www.eggheadcafe.com/articles/20020107.asp
 *
 */


function getInput() {
    return document.getElementById("input-field");
}

function getOutput() {
    return document.getElementById("output-table");
}

function getInputRow() {
    return document.getElementById("input-row");
}

function getTooltipOutput() {
    return document.getElementById("tooltip-output");
}

function LZ(x) {
    return (x >= 10 || x < 0 ? "" : "0") + x;
}

function LZZ(x) {
    return x < 0 || x >= 100 ? "" + x : "0" + LZ(x);
}

var _session_id = null;
var _ln = 0; // local client line count
var _sln = 0; // remote server line count
var _first_prompt = ">>> ";
var _second_prompt = "... ";
var _prompt = _first_prompt;
var _indent = 0; // the indent
// histlist, not sure what these do
var histList = [""]; 
var histPos = 0; 
var _in = null;
var _out = null;
var _fp = null;
// cache for tooltips
var _tooltip_cache = Array();
var _tooltip_current = "";

function endswith(str, chr) {
    if (str.charAt(str.length-1) == chr) {
        return true;
    }
    return false;
}

function gotSession() {
    setMessage("Got a session, id:" + _session_id);
    var input = getInput();
    input.style.display = "inline";
    checkStatus();
    setInterval(checkStatus, 1000);
    
    var msg_id = document.getElementById("session-id");
    var msg_link = document.getElementById("session-link");
    var msg_xml_link = document.getElementById("session-xml-link");
    
    msg_id.innerHTML = _session_id;
    msg_link.href = "clouseau_view?session_id=" + _session_id;
    msg_xml_link.href = "clouseau_tool/get_all_lines_xml?session_id=" + _session_id;
}

function getSession() {
    _session_id = getString("session_id");
    
    if (_session_id != "null") {
        // yay start the check status loop
        gotSession();
        return;
    }
    
    var req = new XMLHttpRequest()
    req.onreadystatechange = function() {
        if(req.readyState == 4) {
            if (req.status != 200) {
                setMessage("Error occured trying to create new session: " + req.statusText + " (" + req.status + ")." , "error");
            } else {
                var xml = req.responseXML.documentElement;
                var session = xml.getElementsByTagName("session")[0];
                _session_id = session.getAttribute("id");
                gotSession();
            };
        };
    };
    req.open("GET", "clouseau_tool/new_session_xml", true);
    req.send("");
    setMessage("Getting a session please wait...");
}

function checkStatus() {
    
    var req = new XMLHttpRequest();
    //debugging mode
    
    req.onreadystatechange = function() {
        //alert(req.readyState);
        if(req.readyState == 4) {
            if (req.status != 200) {
                // error!
                setMessage("Error occured trying to get status: " + req.statusText + " (" + req.status + ")." , "error");
            } else {
                var xml = req.responseXML.documentElement;
                var session= xml.getElementsByTagName("session")[0];
                _sln = session.getAttribute("lines");
                //debugging mode
                //setMessage("Server has " + _sln + " lines and the client has " + _ln + " lines.", "debug")
                if (_sln > _ln) {
                    getLines();
                }
            };
        };
    };
    req.open("POST", "clouseau_tool/get_session_xml", true);
    req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    req.send("session_id=" + _session_id);
}

function sendText(text) {
    // if we have no session id, then we exit
    if (!_session_id) {
        return false;
    }
    text = encodeURIComponent(text);
    var req = new XMLHttpRequest()
    
    req.onreadystatechange = function() {
        if(req.readyState == 4) {
            if (req.status != 200) {
                setMessage("Error occured trying send text to the server: " + req.statusText + " (" + req.status + ")." , "error");
            }
        };
    };
    req.open("POST", "clouseau_tool/process_text_xml", true);
    req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    req.send("session_id=" + _session_id + "&text=" + text);
}

function findToolTip() {
    // if we have no session id, then we exit
    if (!_session_id) {
        return false;
    }
    var text = getInput();
    text = text.value;
    
    var lastLeft = text.lastIndexOf('(');
    var lastRight = text.lastIndexOf(')');
    
    if ((lastLeft > 0) && (lastRight < lastLeft)) {
        /* we have to have a (
            and it has to be before a closing
            bracket, a )
        */
        text = text.slice(0, lastLeft);
        
        if (text == _tooltip_current) {
            // no need to update anything
            return;
        }
        
        /* trim it, then apply a cache */
        text = encodeURIComponent(text);
        
        if (_tooltip_cache[text]) {
            enableToolTip(text);
            return;
        }
        var req = new XMLHttpRequest()
        
        req.onreadystatechange = function() {
            if(req.readyState == 4) {
                if (req.status != 200) {
                    setMessage("Error occured trying to get a tool tip to the server: " + req.statusText + " (" + req.status + ")." , "error");
                } else {
                    // get the data from the XML
                    var xml = req.responseXML.documentElement;
                    xml.normalize();
                    var tip = xml.getElementsByTagName("tooltip")[0];
                    
                    // set the current and the cache
                    _tooltip_cache[text] = tip.firstChild.data;
                    enableToolTip(text);
                }
            };
        };
        req.open("POST", "clouseau_tool/get_tooltip_xml", true);
        req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        req.send("session_id=" + _session_id + "&text=" + text);        
    } else {
        disableToolTip();
    }
}

function disableToolTip() {
    var out = getTooltipOutput();
    out.style.display = "none"; 
    // clear cache
    _tooltip_current = ""; 
}

function enableToolTip(text) {
    // set caches
    _tooltip_current = text;

    // flip
    var tip = _tooltip_cache[text];
    var out = getTooltipOutput();
    out.style.display = "block";
    // ugh
    tip = tip.replace(/\n/g, "<br />");
    out.innerHTML = tip;
}

function getLines() {
    // if we have no session id, then we exit
    if (!_session_id) {
        return false;
    }

    var req = new XMLHttpRequest()
    
    req.onreadystatechange = function() {
        if(req.readyState == 4) {
            // alert(req.responseText);
            
            if (req.status != 200) {
                // error!
                setMessage("Error occured trying to get lines: " + req.statusText + " (" + req.status + ")." , "error");
            } else {
                var xml = req.responseXML.documentElement;
                xml.normalize();
                var lines = xml.getElementsByTagName("line");
                for (var x = 0; x < lines.length; x++) {
                    var command = lines[x].getElementsByTagName("command");
                    var response = lines[x].getElementsByTagName("response");                    
                    var status = lines[x].getAttribute("status");
                    if (status == "input-not-complete") {
                        setPrompt("second");
                    } else {
                        setPrompt("first");
                    }
                    /* if there is a command, or a command and no reponse... */
                    if (command.length > 0) { 
                        var cmd = null;
                        try {
                            cmd = command[0].firstChild.data;
                        }
                        catch (e) {
                            cmd = '';
                        }
                        processOutputLine(cmd, true);
                    }
                    /* if there is no command and response, we've got a blank line */
                    if ((command.length == 0) && (response.length == 0)) {
                        processOutputLine('', true);
                    }
                    if (response.length > 0) {
                        var res = null;
                        try {
                            res = response[0].firstChild.data;
                        }
                        catch (e) {
                            res = '';
                        }
                        processOutputLine(res, false);
                    }
                    // for each line we have increment server count
                    _ln += 1
                };
                setMessage("Done, waiting for input");
            };
            var input = getInput();
            input.style.display = "inline";   
            refocus(_ln);
        };
    };

    req.open("POST", "clouseau_tool/get_lines_xml", true);

    req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    var lines_query = "";
    for (var k = _ln; k < _sln; k++) {
        lines_query += "&line_numbers:list=" + k;
    }
    setMessage("Getting lines, server is at " + _sln + " client is at " + _ln);
    req.send("session_id=" + _session_id + lines_query);
}

function setPrompt(type) {
    var prompt = document.getElementById("input-prompt");
    if (type == "first") {
        _prompt = _first_prompt;
        prompt.innerHTML = _first_prompt;
    } else {
        _prompt = _second_prompt;
        prompt.innerHTML = _second_prompt;
    }
}

function processOutputLine(text, add_prompt) {
    var output = getOutput();
    var input_row = getInputRow();
    
    var code = document.createElement("code");    
    var prompt_code = document.createElement("code");
    
    var output_row = document.createElement("tr");
    var ln_td = document.createElement("td");
    var line_number = document.createElement("a");
    var prompt_td = document.createElement("td");
    var output_td = document.createElement("td");
    
    line_number.name = _ln;
    line_number.innerHTML = LZZ(_ln);
    line_number.className = "line-number";
    
    prompt_code.innerHTML = _prompt;
    prompt_td.appendChild(prompt_code);
    
    ln_td.className = "output-table";
    ln_td.appendChild(line_number);
    output_row.appendChild(ln_td);
    
    if (add_prompt == true) {
        prompt_td.className = "output-table";
        output_row.appendChild(prompt_td);
    } else {
        output_td.colSpan = 2;
    }
    prompt_code.className = "clouseau-code";
    code.innerHTML = text;
    output_td.appendChild(code);
    output_row.appendChild(output_td);
    input_row.parentNode.insertBefore(output_row,input_row);
    
    dp.SyntaxHighlighter.HighlightClouseau(code, text);

}

function setMessage(text, type) {
    if (!type) {
        type = "info";
    }
    if (type == "debug") {
        var msg = document.getElementById("debug-message");
    } else {
        var msg = document.getElementById("message");
    } 
    msg.innerHTML = text;
    msg.className = "clouseau-" + type;   
}



function process() {
    var input = getInput();
    var text = input.value;
    
    histList[histList.length-1] = text;
    histList[histList.length] = "";
    histPos = histList.length - 1;
        
    setMessage("Processing...");
    sendText(text);
    input.value = '';
    
    return false;
}

function PageQueryObject(q) 
{
    if(q.length > 1)
    {
        this.q = q.substring(1, q.length);
    }
    else
    {
        this.q = null;
    }
    this.keyValuePairs = new Array();
    if(q) 
    {
        for(var i=0; i < this.q.split("&").length; i++) 
        {
            this.keyValuePairs[i] = this.q.split("&")[i];
        }
    }
    this.getKeyValuePairs = function() { return this.keyValuePairs; }
    this.getValue = function(s) {
        for(var j=0; j < this.keyValuePairs.length; j++) 
        {
            if(this.keyValuePairs[j].split("=")[0] == s)
            return this.keyValuePairs[j].split("=")[1];
        }
        return null;
    }

    this.getParameters = function() {
        var a = new Array(this.getLength());
        for(var j=0; j < this.keyValuePairs.length; j++)
        {
            a[j] = this.keyValuePairs[j].split("=")[0];
        }
        return a;
    }
    this.getLength = function() { return this.keyValuePairs.length; }
}

function getString(key) {
    var page_object = new PageQueryObject(window.location.search);
    return unescape(page_object.getValue(key));
}

function inputKeydown(e) {
  // Use onkeydown because IE doesn't support onkeypress for arrow keys
  if (e.keyCode == 13) {
     process();
     // hid the tool tip
     disableToolTip();
     return false;
  } 
  
  if (e.keyCode == 38) { // up
    // go up in history if at top or ctrl-up
    if (e.ctrlKey || caretInFirstLine(_in))
      hist(true);
  } else if (e.keyCode == 40) { // down
    // go down in history if at end or ctrl-down
    if (e.ctrlKey || caretInLastLine(_in))
      hist(false);
  }
};

function inputKeyup(e) {
    findToolTip();
};

registerPloneFunction(getSession);
