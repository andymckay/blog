from Products.CMFCore.DirectoryView import createDirectoryView
from Products.CMFCore.utils import getToolByName

from Products.Clouseau.config import layer_name, layer_location, unique_id

def install(self):
    """ Install this product """
    out = []
    skinsTool = getToolByName(self, 'portal_skins')

    # add in the directory view pointing to our skin
    if layer_name not in skinsTool.objectIds():
        createDirectoryView(skinsTool, layer_location, layer_name)
        out.append('Added "%s" directory view to portal_skins' % layer_name)

    # add in the layer to all our skins    
    skins = skinsTool.getSkinSelections()
    for skin in skins:
        path = skinsTool.getSkinPath(skin)
        path = [ p.strip() for p in path.split(',') ]
        if layer_name not in path:
            path.insert(path.index('custom')+1, layer_name)

            path = ", ".join(path)
            skinsTool.addSkinSelection(skin, path)
            out.append('Added "%s" to "%s" skins' % (layer_name, skin))
        else:
            out.append('Skipping "%s" skin' % skin)

	try:
		ctool = getToolByName(self, unique_id)
	except AttributeError:
		self.manage_addProduct['Clouseau'].manage_addTool('Clouseau', None)
    cp = getToolByName(self, "portal_controlpanel")

    if "Clouseau" not in [ c.id for c in cp._actions ]:
        cp.registerConfiglet(
           	"Clouseau",
            "Clouseau",
            "string:${portal_url}/clouseau_list",
            category="Products",
            permission="Manage portal",
            appId="Clouseau",
            imageUrl="clouseau_icon.png",)
            
    return "\n".join(out)
    

def uninstall(self):
    out = []

    # remove the configlets from the portal control panel
    cp = getToolByName(self, 'portal_controlpanel', None)
    if "Clouseau" in [ c.id for c in cp._actions ]:
        cp.unregisterConfiglet("Clouseau")
        out.append('Removed configlet %s Clouseau')

    out.append('Successfully uninstalled %s.Clouseau')
    return "\n".join(out)