# this is the first code that is run by a session
from AccessControl.SecurityManagement import newSecurityManager
from Testing.makerequest import makerequest
from cStringIO import StringIO

app = transaction_manager.beginAndGetApp()
# login the current user
acl_users = app.unrestrictedTraverse(acl_users_path)

uid = acl_users.getUserById(userid)
if uid:
    userobj = acl_users.getUserById(uid)
    if userobj:
        user = userobj.__of__(acl_users)
        newSecurityManager(None, user)
        
    del userobj

response_output = StringIO()
app = makerequest(app, stdout=response_output)

portal = app.unrestrictedTraverse(portal_path)

# clean out variables
del uid
del acl_users
del userid
del StringIO
del makerequest
del newSecurityManager
