product_name = "ClearRSS"
layer_name = "clearrss"
layer_location = "ClearRSS/skins"