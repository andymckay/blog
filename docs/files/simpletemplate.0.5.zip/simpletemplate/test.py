from django.contrib.simpletemplate import simpletemplate
from django.test import signals

original_render = simpletemplate.DjangoSimpleTAL.render

def instrumented_test_render(self, context):
    """
    An instrumented Template render method, providing a signal
    that can be intercepted by the test system Client

    Adapted straight out of django/test/utils.py
    """
    signals.template_rendered.send(sender=self, template=self, context=context)
    return original_render(self, context)

simpletemplate.DjangoSimpleTAL.render = instrumented_test_render
