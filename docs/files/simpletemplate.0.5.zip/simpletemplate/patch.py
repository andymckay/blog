# this patches in so that path not found exceptions
# are never silently suppressed

from simpletal import simpleTALES

def evaluate (self, expr, originalAtts = None):
    try:
        if (originalAtts is not None):
            # Call from outside
            self.globals['attrs'] = originalAtts
        
        # Supports path, exists, nocall, not, and string
        expr = expr.strip ()
        if expr.startswith ('path:'):
            return self.evaluatePath (expr[5:].lstrip ())
        elif expr.startswith ('exists:'):
            return self.evaluateExists (expr[7:].lstrip())
        elif expr.startswith ('nocall:'):
            return self.evaluateNoCall (expr[7:].lstrip())
        elif expr.startswith ('not:'):
            return self.evaluateNot (expr[4:].lstrip())
        elif expr.startswith ('string:'):
            return self.evaluateString (expr[7:].lstrip())
        elif expr.startswith ('python:'):
            return self.evaluatePython (expr[7:].lstrip())
        else:
            # Not specified - so it's a path
            return self.evaluatePath(expr)
    except simpleTALES.PathNotFoundException:
        raise simpleTALES.PathNotFoundException, expr
    else:
        raise

simpleTALES.Context.evaluate = evaluate