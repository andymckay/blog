License:

    LGPL
    
Author:

    Andy McKay
    andy@clearwind.ca

About:

    A simple implementation of the SimpleTAL library for Django. Usage is simple, install place SimpleTAL.
    
    http://www.owlfish.com/software/simpleTAL/
    
    Then place this directory in your django contrib library.
    
    On your view call get_template to load in the template you'd like:

        from django.contrib.simpletemplate.public import get_template
        from django.template import Context
    
        [snip...]
            t = get_template('recipes/recipe_detail.pt')
            # add in a standard Context
            c = Context({ 'object': r, 'code': result, "object_list":_recipe_list() })
            # and render back, simple
            return HttpResponse(t.render(c))
        
    Or using render_to_response:
    
        from django.contrib.simpletemplate.public import render_to_response

        def main(request):
            return render_to_response("main.pt", {})

    Settings:
    
        Media url is provided eg:
        
            tal:attributes="src string:${settings/MEDIA_URL}"
    
    Filters:
    
        The default Django filters are accessible through app/filters eg:
        
            tal:content="python:['filter']['wordcount']('test of count')"
        
        or:
        
            tal:define="count filter/wordcount" tal:content="python:wordcount('test of count')"
    
    Macros:
    
        At start up all page templates are loaded and parsed into a dictionary. Reading the 
        TEMPLATE_DIRS, the foremost directories first. If you have any problems here or templates
        don't seem to be loaded, check your syntax
        
        All templates are loaded into a templates dictionary, so to access a macro
        master in a template, main_template you'd do:
        
            metal:use-macro="templates/main_template/macros/master"
        
        Because all templates use the same namespace, another main_template could override an existing one.

    Logging:
    
        Django does not have a logging framework, so if you want more detailed logs from this there's
        a few lines at the top of simpletemplate.py to uncomment.
    
Credit:

    Stefan Holek and ZPT for Django, a much more robust solution and I was reading bits of that when I wrote this
    
    http://www.zope.org/Members/shh/DjangoPageTemplates