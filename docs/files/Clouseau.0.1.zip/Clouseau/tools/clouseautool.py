# $Id$

from Globals import InitializeClass
from OFS.SimpleItem import SimpleItem
from AccessControl import ClassSecurityInfo
from AccessControl.SecurityManagement import getSecurityManager
from Globals import DevelopmentMode

# package imports
from Products.Clouseau import permissions, sessions

from Products.CMFCore.utils import UniqueObject, getToolByName

from Products.Clouseau.output import wrapper as xmlwrapper
from Products.Clouseau.config import product_name, unique_id
from Products.Clouseau.config import enabled, enabled_only_in_debug_mode

run = False

if enabled:
    run = True

if enabled and not DevelopmentMode and enabled_only_in_debug_mode:
    run = False

if run:
    class ClouseauTool(UniqueObject,  SimpleItem):
        """ The tool for handling the data """
        meta_type = product_name
        id = unique_id
        title = "The Amazing Python Inspector"

        security = ClassSecurityInfo()

        enabled = True

        def __init__(self):
            pass

        security.declarePrivate('new_namespace')
        def new_namespace(self):
            user = getSecurityManager().getUser()
            return dict(portal_path=self.aq_parent.getPhysicalPath(),
                        __name__="__zope_debug__",
                        __doc__=None,
                        userid=user.getId(),
                        acl_users_path=user.aq_parent.getPhysicalPath(),
                        )

        security.declareProtected(permissions.Debug, "new_session")
        def new_session(self):
            """ creates a new session and returns the session id """
            namespace = self.new_namespace()
            id = sessions.new_session(self.new_namespace())
            return id

        security.declareProtected(permissions.Debug, "new_session_xml")
        def new_session_xml(self):
            """ Creates a new session and returns it as xml """
            id = self.new_session()
            return self.get_session_xml(id)
    
        security.declareProtected(permissions.Debug, "process_text")
        def process_text(self, session_id, text):
            """ push a source_text to a session object """
            session = self.get_session(session_id)
            session.putSource(text)

        security.declareProtected(permissions.Debug, "process_text_xml")
        def process_text_xml(self, session_id, text):
            """ push a source_text to a session object """
            session = self.get_session(session_id)
            session.putSource(text)
            return self.get_session_xml(session_id)
            
        security.declareProtected(permissions.Debug, "get_lines")
        def get_lines(self, session_id, line_numbers):
            """ get output lines from a session """
            session = self.get_session(session_id)
            return session.getLines(line_numbers)

        security.declareProtected(permissions.Debug, "get_all_lines")
        def get_all_lines(self, session_id):
            """ get output lines from a session """
            session = self.get_session(session_id)
            return session.getAllLines()

        security.declareProtected(permissions.Debug, "get_all_lines_xml")
        def get_all_lines_xml(self, session_id):
            """ get output lines from a session as xml, useful for debugging """
            lines = self.get_all_lines(session_id)
            return self.get_lines_xml(session_id)

        security.declareProtected(permissions.Debug, "get_session_xml")
        def get_lines_xml(self, session_id, line_numbers=None):
            """ Returns data on a session """
            if line_numbers is not None:
                line_numbers = [ int(l) for l in line_numbers ]
                lines = self.get_lines(session_id, line_numbers)
            elif line_numbers is None:
                # get all the lines
                lines = self.get_all_lines(session_id)
                line_numbers = range(0, len(lines))
            else:
                raise ValueError, "Must specify either line_numbers or lines"
                
            # return line as xml
            xml = xmlwrapper()
        
            elem = xml.xml.createElement("lines")
            k = 0
            for item in lines:
                ln = line_numbers[k]
                k += 1
                # if command or response are empty, just ignore them
                # should never happen that they are both empty
                line = xml.xml.createElement("line")
                line.setAttribute("number", str(ln))
                status = item["status"]
                line.setAttribute("status", str(status))
                command = item.get("input", None)
                response = item.get("output", None)

                
                if command is None and response is None:
                    raise ValueError, "Both the command, and the response is None, this should not happen"
                
                if command is not None:
                    command_node = xml.xml.createElement("command")
                    command_text = xml.xml.createTextNode(command)
                    command_node.appendChild(command_text)

                    line.appendChild(command_node)

                # only give a response 
                if response is not None:
                    response_node = xml.xml.createElement("response")
                    response_text = xml.xml.createTextNode(response)
                    response_node.appendChild(response_text)
            
                    line.appendChild(response_node)

                elem.appendChild(line)

            xml.add(self._get_session_xml(xml, session_id))
            xml.add(elem)

            self._set_content_type()
            return str(xml)

        security.declareProtected(permissions.Debug, "get_session_xml")
        def get_session_xml(self, session_id):
            """ Returns data on a session """
            session = self.get_session(session_id)
            # return id as xml
            xml = xmlwrapper()
            xml.add(self._get_session_xml(xml, session_id))
        
            self._set_content_type()
            return str(xml)

        # protected utility functions
        def _get_session_xml(self, xml, session_id):
            session = self.get_session(session_id)
            elem = xml.xml.createElement("session")
            elem.setAttribute("id", str(session_id))
            elem.setAttribute("lines", str(session.getLinesLength()))
            return elem

        def _set_content_type(self):
            self.REQUEST.RESPONSE.setHeader('Content-Type', 'text/xml')

        security.declareProtected(permissions.Debug, "get_session")
        def get_session(self, session_id):
            """ returns a session given it's session_id """
            session = sessions.get_session(int(session_id))
            return session

        security.declareProtected(permissions.Debug, "list_session_info")
        def list_session_info(self):
            """ returns a session given it's session_id """
            return [dict(session_id=sid,
                         lines_length=self.get_session(sid).getLinesLength())
                    for sid in sessions.list_session_ids()]

        security.declareProtected(permissions.Debug, "get_session_namespace")
        def get_session_namespace(self, session_id):
            return [dict(name=name, value=value) for name, value in
                    self.get_session(session_id).interpreter.locals.items()]

        security.declareProtected(permissions.Debug, "stop_session")
        def stop_session(self, session_id, REQUEST=None, RESPONSE=None):
            """ kill a session? """
            session = self.get_session(session_id)
            # what is this meant to be doing?
            session.stopSession()
            sessions.del_session(int(session_id))
            if RESPONSE:
                url = "clouseau_list?portal_status_message=Session deleted"
                RESPONSE.redirect(url)

else:    
    class ClouseauTool(UniqueObject,  SimpleItem):
        """ The tool for handling the data """
        meta_type = product_name
        id = unique_id
        title = "The Amazing Python Inspector (Not enabled)"

        security = ClassSecurityInfo()
        
        enabled = False

InitializeClass(ClouseauTool)
