# Licensed under the Enfold Enterprise Server License Agreement
# Copyright(c), 2004-6, Enfold Systems, Inc.,  ALL RIGHTS RESERVED
"""
$Id: __init__.py 4961 2006-05-24 17:23:07Z sidnei $
"""
