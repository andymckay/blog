from Products.CMFCore.utils import getToolByName

unique_id = "ajax_proxy_tool"

def install(self):
    """Install this product """
    out = []
    aptool = getToolByName(self, 'unique_id', None)
    if aptool is None:
        out.append("Added in AjaxProxy tool.")
        self.manage_addProduct['AjaxProxy'].manage_addTool('AjaxProxy')

    return "\n".join(out)

def uninstall(self):
    """ Uninstall this product """
    out = []
    out.append("Deleted AjaxProxy tool.")
    self.manage_delObjects([unique_id,])
    return "\n".join(out)
