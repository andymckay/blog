Copyright ClearWind Consulting, 2006
License: LGPL

Requirements:

- None

About:
    
    An Ajax Proxy server for Plone. For more information on installing and configuring and what this product actually does, please see the docs directory.

    By itself this product is inert, it installs a tool and config file, you need another product to have this do anything.

Author:

    Andy McKay
    andy@clearwind.ca
